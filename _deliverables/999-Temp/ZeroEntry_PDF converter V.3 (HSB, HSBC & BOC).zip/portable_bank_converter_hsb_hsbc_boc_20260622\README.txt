Hong Kong Bank PDF to Excel Converter Prototype
===============================================

Supported statement layouts in this prototype:
- Hang Seng Bank / HSB statement layout from the tested sample
- HSBC Business Direct HKD Current and HKD Savings layouts
- HSBC Business Direct Foreign Currency Savings layouts, split into one sheet per currency
- Bank of China (Hong Kong) / BOC HKD Savings and HKD Current statement layout

How to use
----------
1. Put PDF files into the BB folder.
2. Double-click run_converter.bat.
3. Generated Excel files will appear in the BB2 folder.

Output columns
--------------
Bank_Account, Date, Description, Deposit, Withdrawal, Balance, Control

Notes
-----
- The converter auto-detects HSBC vs HSB from the first pages of each PDF.
- BOC Chinese descriptions are preserved from the PDF text layer.
- HSBC Foreign Currency Savings is exported into separate sheets such as:
  - HSBC USD Foreign Currency Savings
  - HSBC CNY Foreign Currency Savings
  - HSBC JPY Foreign Currency Savings
  - HSBC EUR Foreign Currency Savings
- The parser is coordinate-based, so new bank/PDF layouts should be calibrated with sample PDFs before production use.
